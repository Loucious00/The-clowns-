module.exports = {
  name: 'clown42',
  desc: 'Template fun #42',
  usage: '!clown42',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown42 !' });
  }
};