module.exports = {
  name: 'clown80',
  desc: 'Template fun #80',
  usage: '!clown80',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown80 !' });
  }
};