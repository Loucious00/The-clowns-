module.exports = {
  name: 'clown79',
  desc: 'Template fun #79',
  usage: '!clown79',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown79 !' });
  }
};