module.exports = {
  name: 'clown131',
  desc: 'Template fun #131',
  usage: '!clown131',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown131 !' });
  }
};