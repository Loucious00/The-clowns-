module.exports = {
  name: 'clown193',
  desc: 'Template fun #193',
  usage: '!clown193',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown193 !' });
  }
};