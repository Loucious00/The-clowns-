module.exports = {
  name: 'clown13',
  desc: 'Template fun #13',
  usage: '!clown13',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown13 !' });
  }
};