module.exports = {
  name: 'fortune',
  desc: 'Donne une prédiction drôle',
  usage: '!fortune',
  admin: false,
  exec: async ({ sock, from }) => {
    const f = [
      "Tu trouveras de la monnaie sous un canapé.",
      "Aujourd'hui est un bon jour pour un gâteau.",
      "Un ami t'enverra un message étrange — réponds avec un emoji."
    ];
    await sock.sendMessage(from, { text: '🔮 Fortune : ' + f[Math.floor(Math.random() * f.length)] });
  }
};