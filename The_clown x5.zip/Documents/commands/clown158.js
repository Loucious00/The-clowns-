module.exports = {
  name: 'clown158',
  desc: 'Template fun #158',
  usage: '!clown158',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown158 !' });
  }
};