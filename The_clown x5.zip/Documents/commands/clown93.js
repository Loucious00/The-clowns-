module.exports = {
  name: 'clown93',
  desc: 'Template fun #93',
  usage: '!clown93',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown93 !' });
  }
};