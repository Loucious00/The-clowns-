module.exports = {
  name: 'clown140',
  desc: 'Template fun #140',
  usage: '!clown140',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown140 !' });
  }
};