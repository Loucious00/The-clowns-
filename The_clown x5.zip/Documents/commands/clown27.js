module.exports = {
  name: 'clown27',
  desc: 'Template fun #27',
  usage: '!clown27',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown27 !' });
  }
};