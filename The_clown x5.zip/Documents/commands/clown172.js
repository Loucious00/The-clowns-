module.exports = {
  name: 'clown172',
  desc: 'Template fun #172',
  usage: '!clown172',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown172 !' });
  }
};