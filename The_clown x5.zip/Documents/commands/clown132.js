module.exports = {
  name: 'clown132',
  desc: 'Template fun #132',
  usage: '!clown132',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown132 !' });
  }
};