module.exports = {
  name: 'clown78',
  desc: 'Template fun #78',
  usage: '!clown78',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown78 !' });
  }
};