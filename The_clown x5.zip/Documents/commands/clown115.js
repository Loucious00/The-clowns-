module.exports = {
  name: 'clown115',
  desc: 'Template fun #115',
  usage: '!clown115',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown115 !' });
  }
};