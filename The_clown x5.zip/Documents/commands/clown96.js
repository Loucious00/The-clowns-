module.exports = {
  name: 'clown96',
  desc: 'Template fun #96',
  usage: '!clown96',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown96 !' });
  }
};