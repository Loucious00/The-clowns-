module.exports = {
  name: 'clown75',
  desc: 'Template fun #75',
  usage: '!clown75',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown75 !' });
  }
};