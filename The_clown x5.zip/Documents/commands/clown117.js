module.exports = {
  name: 'clown117',
  desc: 'Template fun #117',
  usage: '!clown117',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown117 !' });
  }
};