module.exports = {
  name: 'clown143',
  desc: 'Template fun #143',
  usage: '!clown143',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown143 !' });
  }
};