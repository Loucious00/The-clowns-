module.exports = {
  name: 'ping',
  desc: 'Répond pong',
  usage: '!ping',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'pong' });
  }
};