module.exports = {
  name: 'clown68',
  desc: 'Template fun #68',
  usage: '!clown68',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown68 !' });
  }
};