module.exports = {
  name: 'clown116',
  desc: 'Template fun #116',
  usage: '!clown116',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown116 !' });
  }
};