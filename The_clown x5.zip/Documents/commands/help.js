module.exports = {
  name: 'help',
  desc: 'Liste des commandes (extrait)',
  usage: '!help',
  admin: false,
  exec: async ({ sock, from, commands, CONFIG }) => {
    const items = Array.from(commands.values()).slice(0, 200).map(c => `${CONFIG.PREFIX}${c.name} — ${c.desc || ''}`);
    await sock.sendMessage(from, { text: '🔥 THE CLOWN X5 — Menu (extrait):\n' + items.join('\n') });
  }
};