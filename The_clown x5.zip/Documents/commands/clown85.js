module.exports = {
  name: 'clown85',
  desc: 'Template fun #85',
  usage: '!clown85',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown85 !' });
  }
};