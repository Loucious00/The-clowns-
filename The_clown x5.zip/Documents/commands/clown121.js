module.exports = {
  name: 'clown121',
  desc: 'Template fun #121',
  usage: '!clown121',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown121 !' });
  }
};