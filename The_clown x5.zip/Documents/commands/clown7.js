module.exports = {
  name: 'clown7',
  desc: 'Template fun #7',
  usage: '!clown7',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown7 !' });
  }
};