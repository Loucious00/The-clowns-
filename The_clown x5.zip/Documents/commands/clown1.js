module.exports = {
  name: 'clown1',
  desc: 'Template fun #1',
  usage: '!clown1',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown1 !' });
  }
};