module.exports = {
  name: 'clown29',
  desc: 'Template fun #29',
  usage: '!clown29',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown29 !' });
  }
};