module.exports = {
  name: 'clown34',
  desc: 'Template fun #34',
  usage: '!clown34',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown34 !' });
  }
};