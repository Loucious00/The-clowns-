module.exports = {
  name: 'clown103',
  desc: 'Template fun #103',
  usage: '!clown103',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown103 !' });
  }
};