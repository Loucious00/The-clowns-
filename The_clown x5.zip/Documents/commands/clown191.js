module.exports = {
  name: 'clown191',
  desc: 'Template fun #191',
  usage: '!clown191',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown191 !' });
  }
};