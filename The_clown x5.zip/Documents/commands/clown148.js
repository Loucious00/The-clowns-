module.exports = {
  name: 'clown148',
  desc: 'Template fun #148',
  usage: '!clown148',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown148 !' });
  }
};