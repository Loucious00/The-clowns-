module.exports = {
  name: 'clown59',
  desc: 'Template fun #59',
  usage: '!clown59',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown59 !' });
  }
};