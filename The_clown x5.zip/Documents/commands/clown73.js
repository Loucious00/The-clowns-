module.exports = {
  name: 'clown73',
  desc: 'Template fun #73',
  usage: '!clown73',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown73 !' });
  }
};