module.exports = {
  name: 'clown192',
  desc: 'Template fun #192',
  usage: '!clown192',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown192 !' });
  }
};