module.exports = {
  name: 'clown184',
  desc: 'Template fun #184',
  usage: '!clown184',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown184 !' });
  }
};