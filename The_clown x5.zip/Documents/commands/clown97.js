module.exports = {
  name: 'clown97',
  desc: 'Template fun #97',
  usage: '!clown97',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown97 !' });
  }
};