module.exports = {
  name: 'clown136',
  desc: 'Template fun #136',
  usage: '!clown136',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown136 !' });
  }
};