module.exports = {
  name: 'clown181',
  desc: 'Template fun #181',
  usage: '!clown181',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown181 !' });
  }
};