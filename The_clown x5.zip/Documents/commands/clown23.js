module.exports = {
  name: 'clown23',
  desc: 'Template fun #23',
  usage: '!clown23',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown23 !' });
  }
};