module.exports = {
  name: 'clown145',
  desc: 'Template fun #145',
  usage: '!clown145',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown145 !' });
  }
};