# The_Clown_x5 — Bad Clown edition (starter)

Quick start:
1. unzip and cd into folder
2. npm install
3. export OPENAI_API_KEY=your_key (optional)
4. export OWNER_NUMBER=229XXXXXXXX (optional)
5. npm start
6. open http://localhost:3000 and scan QR to link WhatsApp

Notes:
- data/ stores auth info. Keep it private.
- Use responsibly. WhatsApp may ban accounts for spam.
- To create 2000 commands, run: node scripts/generate.js 2000
