module.exports = {
  name: 'clown17',
  desc: 'Template fun #17',
  usage: '!clown17',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown17 !' });
  }
};