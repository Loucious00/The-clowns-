module.exports = {
  name: 'clown5',
  desc: 'Template fun #5',
  usage: '!clown5',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown5 !' });
  }
};