module.exports = {
  name: 'clown55',
  desc: 'Template fun #55',
  usage: '!clown55',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown55 !' });
  }
};