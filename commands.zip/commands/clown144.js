module.exports = {
  name: 'clown144',
  desc: 'Template fun #144',
  usage: '!clown144',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown144 !' });
  }
};