module.exports = {
  name: 'clown89',
  desc: 'Template fun #89',
  usage: '!clown89',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown89 !' });
  }
};