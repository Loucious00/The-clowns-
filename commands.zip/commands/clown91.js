module.exports = {
  name: 'clown91',
  desc: 'Template fun #91',
  usage: '!clown91',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown91 !' });
  }
};