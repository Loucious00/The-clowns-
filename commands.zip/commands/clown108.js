module.exports = {
  name: 'clown108',
  desc: 'Template fun #108',
  usage: '!clown108',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown108 !' });
  }
};