module.exports = {
  name: 'clown70',
  desc: 'Template fun #70',
  usage: '!clown70',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown70 !' });
  }
};