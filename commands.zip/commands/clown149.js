module.exports = {
  name: 'clown149',
  desc: 'Template fun #149',
  usage: '!clown149',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown149 !' });
  }
};