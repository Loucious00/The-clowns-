module.exports = {
  name: 'clown162',
  desc: 'Template fun #162',
  usage: '!clown162',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown162 !' });
  }
};