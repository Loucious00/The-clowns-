module.exports = {
  name: 'clown16',
  desc: 'Template fun #16',
  usage: '!clown16',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown16 !' });
  }
};