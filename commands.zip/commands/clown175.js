module.exports = {
  name: 'clown175',
  desc: 'Template fun #175',
  usage: '!clown175',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown175 !' });
  }
};