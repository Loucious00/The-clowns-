module.exports = {
  name: 'clown196',
  desc: 'Template fun #196',
  usage: '!clown196',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown196 !' });
  }
};