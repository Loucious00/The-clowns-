module.exports = {
  name: 'clown135',
  desc: 'Template fun #135',
  usage: '!clown135',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown135 !' });
  }
};