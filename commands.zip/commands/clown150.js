module.exports = {
  name: 'clown150',
  desc: 'Template fun #150',
  usage: '!clown150',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown150 !' });
  }
};