module.exports = {
  name: 'clown39',
  desc: 'Template fun #39',
  usage: '!clown39',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown39 !' });
  }
};