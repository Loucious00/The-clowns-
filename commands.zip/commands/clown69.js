module.exports = {
  name: 'clown69',
  desc: 'Template fun #69',
  usage: '!clown69',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown69 !' });
  }
};