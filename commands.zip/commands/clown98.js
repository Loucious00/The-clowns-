module.exports = {
  name: 'clown98',
  desc: 'Template fun #98',
  usage: '!clown98',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown98 !' });
  }
};