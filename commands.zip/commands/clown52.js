module.exports = {
  name: 'clown52',
  desc: 'Template fun #52',
  usage: '!clown52',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown52 !' });
  }
};