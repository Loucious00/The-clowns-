module.exports = {
  name: 'clown65',
  desc: 'Template fun #65',
  usage: '!clown65',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown65 !' });
  }
};