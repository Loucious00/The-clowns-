module.exports = {
  name: 'clown49',
  desc: 'Template fun #49',
  usage: '!clown49',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown49 !' });
  }
};