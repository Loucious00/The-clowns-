module.exports = {
  name: 'clown25',
  desc: 'Template fun #25',
  usage: '!clown25',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown25 !' });
  }
};