module.exports = {
  name: 'clown119',
  desc: 'Template fun #119',
  usage: '!clown119',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown119 !' });
  }
};