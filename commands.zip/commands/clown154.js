module.exports = {
  name: 'clown154',
  desc: 'Template fun #154',
  usage: '!clown154',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown154 !' });
  }
};