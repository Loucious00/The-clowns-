module.exports = {
  name: 'clown44',
  desc: 'Template fun #44',
  usage: '!clown44',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown44 !' });
  }
};