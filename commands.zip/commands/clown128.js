module.exports = {
  name: 'clown128',
  desc: 'Template fun #128',
  usage: '!clown128',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown128 !' });
  }
};