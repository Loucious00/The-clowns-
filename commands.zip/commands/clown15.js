module.exports = {
  name: 'clown15',
  desc: 'Template fun #15',
  usage: '!clown15',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown15 !' });
  }
};