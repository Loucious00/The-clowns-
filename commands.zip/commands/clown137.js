module.exports = {
  name: 'clown137',
  desc: 'Template fun #137',
  usage: '!clown137',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown137 !' });
  }
};