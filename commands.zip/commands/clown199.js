module.exports = {
  name: 'clown199',
  desc: 'Template fun #199',
  usage: '!clown199',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown199 !' });
  }
};