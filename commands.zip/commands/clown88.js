module.exports = {
  name: 'clown88',
  desc: 'Template fun #88',
  usage: '!clown88',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown88 !' });
  }
};