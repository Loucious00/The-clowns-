module.exports = {
  name: 'clown166',
  desc: 'Template fun #166',
  usage: '!clown166',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown166 !' });
  }
};