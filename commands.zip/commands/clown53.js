module.exports = {
  name: 'clown53',
  desc: 'Template fun #53',
  usage: '!clown53',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown53 !' });
  }
};