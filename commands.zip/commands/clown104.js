module.exports = {
  name: 'clown104',
  desc: 'Template fun #104',
  usage: '!clown104',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown104 !' });
  }
};