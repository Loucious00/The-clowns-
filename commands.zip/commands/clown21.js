module.exports = {
  name: 'clown21',
  desc: 'Template fun #21',
  usage: '!clown21',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown21 !' });
  }
};