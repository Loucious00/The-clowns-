module.exports = {
  name: 'clown139',
  desc: 'Template fun #139',
  usage: '!clown139',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown139 !' });
  }
};