module.exports = {
  name: 'clown122',
  desc: 'Template fun #122',
  usage: '!clown122',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown122 !' });
  }
};