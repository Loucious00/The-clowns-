module.exports = {
  name: 'clown113',
  desc: 'Template fun #113',
  usage: '!clown113',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown113 !' });
  }
};