module.exports = {
  name: 'clown37',
  desc: 'Template fun #37',
  usage: '!clown37',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown37 !' });
  }
};