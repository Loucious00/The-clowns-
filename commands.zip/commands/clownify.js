module.exports = {
  name: 'clownify',
  desc: 'Transforme un texte style clown',
  usage: '!clownify <texte>',
  admin: false,
  exec: async ({ sock, from, args }) => {
    const t = args.join(' ');
    if (!t) return await sock.sendMessage(from, { text: 'Usage: !clownify <texte>' });
    let out = '';
    for (let i = 0; i < t.length; i++) out += (i % 2 ? t[i].toLowerCase() : t[i].toUpperCase());
    out = '🤡 ' + out + ' 🤡';
    await sock.sendMessage(from, { text: out });
  }
};