module.exports = {
  name: 'clown102',
  desc: 'Template fun #102',
  usage: '!clown102',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown102 !' });
  }
};