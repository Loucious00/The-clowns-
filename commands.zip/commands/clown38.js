module.exports = {
  name: 'clown38',
  desc: 'Template fun #38',
  usage: '!clown38',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown38 !' });
  }
};