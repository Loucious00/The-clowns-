module.exports = {
  name: 'clown107',
  desc: 'Template fun #107',
  usage: '!clown107',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown107 !' });
  }
};