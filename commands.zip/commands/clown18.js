module.exports = {
  name: 'clown18',
  desc: 'Template fun #18',
  usage: '!clown18',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown18 !' });
  }
};