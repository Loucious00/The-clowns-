module.exports = {
  name: 'clown6',
  desc: 'Template fun #6',
  usage: '!clown6',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown6 !' });
  }
};