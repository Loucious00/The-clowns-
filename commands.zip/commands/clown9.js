module.exports = {
  name: 'clown9',
  desc: 'Template fun #9',
  usage: '!clown9',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown9 !' });
  }
};