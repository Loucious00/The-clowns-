module.exports = {
  name: 'clown118',
  desc: 'Template fun #118',
  usage: '!clown118',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown118 !' });
  }
};