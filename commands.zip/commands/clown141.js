module.exports = {
  name: 'clown141',
  desc: 'Template fun #141',
  usage: '!clown141',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown141 !' });
  }
};