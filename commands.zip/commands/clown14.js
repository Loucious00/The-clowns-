module.exports = {
  name: 'clown14',
  desc: 'Template fun #14',
  usage: '!clown14',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown14 !' });
  }
};