module.exports = {
  name: 'clown26',
  desc: 'Template fun #26',
  usage: '!clown26',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown26 !' });
  }
};