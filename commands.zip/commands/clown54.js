module.exports = {
  name: 'clown54',
  desc: 'Template fun #54',
  usage: '!clown54',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown54 !' });
  }
};