module.exports = {
  name: 'clown87',
  desc: 'Template fun #87',
  usage: '!clown87',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown87 !' });
  }
};